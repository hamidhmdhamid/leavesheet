import { createContext } from 'react';

export const ContextApp = createContext({ token: '' });
