const Home = props => {
  return <>"با w ww ww ww www w w w w w سیلام خدمت شما"</>;
};

export default Home;
